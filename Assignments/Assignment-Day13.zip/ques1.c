/*1. Write a program to read the Roll No, name and marks of a student and store it in a text file.If the file already exists, add information to it.*/

#include<stdio.h>
#include<stdlib.h>

void main()
{ 
	FILE * fptr;
	
	char name[5];
	int i,n,rn;
	float mk;
	
	printf("Enter the number of Students:/n");
	scanf("%d",&n);
	fptr = fopen("/home/asif/March22/c-module/day13/ques1.txt","a");
	
	if(fptr==NULL)
	{
		printf("Error!\n");
		exit(0);
	}
	printf("File Open Successfull\n");
	
	for(i=0;i<n;i++) 
	{
		printf("Enter RollNo:");
		scanf("%d",&rn);
		printf("For RollNo %d \tEnter name:",rn);
		scanf("%s",name);
		printf("Enter marks:");
		scanf("%f",&mk);
		fprintf(fptr,"RollNo:%d\tName:%s\tMarks:%f\n",rn,name,mk);
		
	}
	fclose(fptr);
}
