#include<stdio.h>
#include"myheader.h"
int add(int a,int b)
{
     int c;
     c=a+b;
     printf("\nAddition = %d",c);
}     
