/* Write a program to read and print an Employee’s details using Structure.Use array of structures and pointer to the array of structures concepts. */

#include<stdio.h>

struct employee
{
	int empid;
	char name[20];
	double salary;
};

struct employee emp[20];

int main()
{
	struct employee emp[20];
	struct employee *ptr;
	int i,n;
	ptr = emp;
	printf("Total number of employee data to be entered\n");
	scanf("%d",&n);

	for(i=0; i<n; i++)
	{
		printf("Enter detail of Employee %d\n", (i+1));
		printf("Enter the employee name: \n");
		scanf("%s",ptr->name);
		printf("Enter the employee id: \n");
		scanf("%d",&ptr->empid);
		printf("Enter the employee salary: \n");
		scanf("%lf",&ptr->salary);
		
		ptr++;
	}
	ptr=emp;
	printf("Employee Name\t Id\t Salary\n");
	for(i=0; i<n; i++)
	{
		printf("%s\t %d\t %lf\n",ptr->name, ptr->empid, ptr->salary);
		ptr++;
	}
	return 0;
}
