#include <stdio.h>

int main()
{
// int constant
const int intVal = 20;

// Real constant
const float floatVal = 4.14;

// char constant
const char charVal = 'A';

// string constant
const char stringVal[20] = "SWAPNIL";

printf("Integer constant:%d \n", intVal );
printf("Floating point constant: %.2f\n", floatVal );
printf("Character constant: %c\n", charVal );
printf("String constant: %s\n", stringVal);

return 0;
}
