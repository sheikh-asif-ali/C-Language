/*Define a structure “complex” (use typedef) to read two complex numbers and perform addition, subtraction of these two complex numbers and display the result.*/

#include<stdio.h>
typedef struct complex
{
    float real;
    float imaginary;
}c[2];

void main()
{
    struct complex num1, num2, sum ,sub;
    printf("Enter real and imaginary part of first complex number:\n");
    scanf("%f%f", &num1.real, &num1.imaginary);
    printf("Enter real and imaginary part of second complex number:\n");
    scanf("%f%f", &num2.real, &num2.imaginary);

    sum.real = num1.real + num2.real;
    sum.imaginary = num1.imaginary + num2.imaginary;
    sub.real = num1.real - num2.real;
    sub.imaginary = num1.imaginary - num2.imaginary;


    printf("SUM = %0.2f + i %0.2f\n", sum.real, sum.imaginary);
    printf("SUB = %0.2f +i %0.2f\n", sub.real, sub.imaginary);
}
