/* Define structure with two members (one int and other char). Also define union with two members (one int and other char). Print the sizes of
structure and union in number of bytes. Initialize union/structures members and print. */

#include<stdio.h>

union union_stud
{
	// defining a union
	char name[5];
	int marks;

}u_stud;

        struct stuct_stud
	{
	char name[5];
	int marks;

        }s_stud;
	
int main()
{
	printf("size of structure = %ld\n", sizeof(u_stud));
	printf("size of union = %ld\n", sizeof(s_stud));

	return 0;
}



