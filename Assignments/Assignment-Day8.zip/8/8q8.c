/*Write a C program to find reverse of a string using pointers.*/


#include <stdio.h>
#include <stdlib.h>
#include<string.h>
int main()
{
    char s1[100],s2[100];
    char *p1,*p2;
    printf("Enter a String\n");
    gets(s1);
    p1=s1+strlen(s1)-1;
    p2=s2;
    while(p1>=s1)
    {
       *p2=*p1;
        p2++;
        p1--;
    }
    *p2='\0';
    printf("Original String: %s\n",s1);
    printf("Reversed String: %s",s2);
    return 0;
}

