//6.write a cprogram to print all element of two dimentional array using pointer.//
#include<stdio.h> 
void main()
{
int i,j;
int a[2][2]={10,11,12,33};
for (i=0;i<2;i++)
{
for (j=0;j<2;j++)
printf("%d",*(*(a+i)+j));
printf("\n");
}
return 0;
}
