//2.write a c program to read through an array of any type using pointer.copy the element of the first array to second array using pointer.Hint a[i]=*(a+i)//

#include<stdio.h>
void print(int a[],int n);
void main()
{
	int i,n,sou[10],des[10];
	int *s_ptr=sou;
	int *d_ptr=des;
	int *e_ptr;
	
	printf("Enter Size of Array\n");
	scanf("%d",&n);
	printf("Enter the elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",(s_ptr + i));
	}
	
	e_ptr=&sou[n- 1];
	
	printf("\nFirst Pointer Before Copying:\t");
	print(sou,n);
	
	printf("\nSecond Pointer Before Copying:\t");
	print(des,n);
	
	while(s_ptr <= e_ptr)
    	{
		*d_ptr = *s_ptr;
		s_ptr++;
		d_ptr++;
    	}
    	
	printf("\nFirst Pointer After Copying:\t");
	print(sou,n);
	
	printf("\nSecond Pointer After Copying:\t");
	print(des,n);
}	
void print(int *a,int n)
{	
	int i;
	for(i=0;i<n;i++)
	{
		printf( "%d\t" ,*(a+i));
	}printf("\n");
	
}
