//3.write a c program to element (read from standard input) in a array and point the first array to second array using pointer.//
#include<stdio.h>
int main()
{
int arr[100],n,i;
int *ptr = arr;
printf("enter the size of array: ");
scanf("%d",&n);
printf("enter the elements in array :\n");
for(i=0;i<n;i++)
{
scanf("%d",&ptr[i]);
}
printf("array element:");
for(i=0;i<n;i++)
{
printf("%d",i[ptr]);
}
}
