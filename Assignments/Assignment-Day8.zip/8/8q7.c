 //7.implemwent string lbr function strlen ,strcpy,strcat,strcmp,with same written values and all error handling features using pointer.//
 
#include<stdio.h>
#include<string.h>
int main()
{
char s1[10] ="boo";
char s2[10] ="voo";                         
char s3[10];
int len,i,j,k;
len= strlen (s1);
printf("length of string = %d",len );
strcpy(s2,s1);
printf("string s1 is: %s",s2);


strcat(s1,s2);
printf("concatenation using strcat :%s",s1);


i=strcmp(s1,"boo");
j=strcmp(s1,"voo");
k=strcmp(s1,"boo baby");
printf("%d ,%d, %d" ,i, j, k);

return 0;
}
