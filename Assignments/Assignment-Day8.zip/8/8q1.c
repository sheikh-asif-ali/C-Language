//1.write program to perform swap operation.//
#include<stdio.h>

void swapping(int,int);

void swapping(int c, int d)
 { 
	int tmp; 
	printf("In function,before swap:%d\t %d\n", c , d); 
	tmp = c;  
	c = d; 
	d = tmp; 
	printf("In function,after swap: %d\t %d\n", c , d); 
}
void main( ) 
{	 int a,b;
	 a=5; b=10;
	 printf("Before Swap in main: %d\t %d\n", a, b); 
	swapping(a,b); 
	printf("After Swap in main: %d\t %d\n", a, b); 
}

