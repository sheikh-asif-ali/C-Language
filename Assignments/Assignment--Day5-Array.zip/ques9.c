//9. Write a C program to copy the elements of one 2-D array to another 2-D array.(ex 6 elements)//

#include<stdio.h>
int main()
{
int a[2][3],b[2][3],i,j,sum=0;
printf("enter 6 element");
for(i=0;i<2;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&a[i][j]);
}
}
for(i=0;i<2;i++)
{
for(j=0;j<3;j++)
{
b[i][j]=a[i][j];
}
}
for(i=0;i<2;i++)
{
for(j=0;j<3;j++)
{
printf("%d",b[i][j]);
}
}
}
