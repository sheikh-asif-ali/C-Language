//4. write a c program to find greatest element array in 1 dimentional array

#include<stdio.h>
int main()
{
int a[5]={7,3,9,13,18};
int large,i;
large=a[0];
for(i=1;i<5;i++)
{
if(a[i]>large)
{
large=a[i];
}
}
printf("largest %d\n",large);
}
