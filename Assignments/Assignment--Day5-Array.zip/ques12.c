//12. write a c program to display 3d array with element address.

#include<stdio.h>
int main()
{
int a[3][3][3],i,j,r,sum=0;
for(i=1;i<3;i++)
for(j=1;j<3;j++)
for(r=1;r<3;r++)
{
printf("initiatilizing the array element a[%d][%d][%d]\n",i,j,r);
a[i][j][r]=(i*j*r*5);
}
printf("arrays values are..\n");
for(i=1;i<3;i++)
for(j=1;j<3;j++)
for(r=1;r<3;r++)
{
printf("\n");
for(r=i+j;r<3;r++)
{
printf("a[%d]\t",a[i][j][r]);
printf("%d...addr is %p\n",a[i][j][r],&a[i][j][r]);
}
return 0;
}
}
