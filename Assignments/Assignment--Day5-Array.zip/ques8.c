//8. write a c program to display 2d array with element address.


#include<stdio.h>
int main()
{
int a[3][3],i,j,sum=0;
for(i=0;i<3;i++)
for(j=0;j<3;j++)
{
printf("initiatilizing the array element a[%d][%d]\n",i,j);
a[i][j]=(i*j*5);
}
printf("arrays values are..\n");
for(i=0;i<3;i++)
for(j=0;j<3;j++)
{
printf("\n");
for(j=i+1;j<3;j++)
{
printf("a[%d]\t",a[i][j]);
printf("%d...addr is %p\n",a[i][j],&a[i][j]);
}
return 0;
}
}
