//7. write a c program remove the duplicate of integer 1d array.

#include<stdio.h>
int main()
{
int a[7]={4,4,3,2,7,2,4},i,j,k,temp,n=7;
printf("Enter array element: ");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]==a[j])
{
for(k=j;k<n;k++)
{
a[k]=a[k+1];
}
n--;
j--;
}
}
}
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
}
