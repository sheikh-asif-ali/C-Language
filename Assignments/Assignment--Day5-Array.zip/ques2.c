//2. write a c program to count the frequency of each number in a 1-D array.all the elements in the are integers.
#include<stdio.h>
int main()
{
int a[10],i,freq=0,key;
for (i=0;i<10;i++)
{
printf("\n Enter number :");
scanf("%d",&a[i]);
}
printf("\n Enter number to find freqency :");
scanf ("%d",&key);
for(i=0;i<10;i++)
if (a[i]==key)
freq++;
printf("\n freq of %d is %d",key,freq);
return 0;
}
